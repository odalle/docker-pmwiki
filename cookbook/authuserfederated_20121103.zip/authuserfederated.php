<?php
/**
 * authuserfederated.php
 *
 * PMWiki authuser.php extension for federated authentication
 *
 * Currently supports authentication trough google or any
 * standard OpenID provider (willing to give user firstname and lastname)
 *
 * To add a login with google button to your Site.AuthForm or any other page use
 * <code>
 *  (:google_loginbox:)
 * </code>
 *
 * and / or
 *
 * <code>
 *  (:openid_loginbox:)
 * </code>
 * 
 * You can also set an openId error message with:
 * <code>
 *  (:if enabled BadOpenID:)* $[OpenID identifier not recognized] 
 * </code> 
 * 
 * If you want the logout text to appear, modify Site.PageActions (and other similar locations) to add
 * (:if authid:)
 * %item rel=nofollow class=logout    accesskey="$[ak_logout]"%''  [-[[{*$FullName}?action=logout | $[Logout] ]]-]''   
 *
 * Additionally you need to ad the Google/OpenID auth to SiteAdmin.AuthUser
 * <code>
 *  google://module
 * </code>
 *
 * The extension depends on Mewp's openid.php library, and requires Curl and PHP 5.
 *
 * @author Ville Takanen, Guy Moreau
 * @copyright Copyright (c) 2010, Ville Takanen
 * @copyright Copyright (c) 2012, Guy Moreau 
 * @license http://www.opensource.org/licenses/mit-license.php MIT
 * @version 20121103
 *
 * Original open-id extension for pmwiki (by Michael Novak) was great help when
 * starting to write this extension.
 * 
 * 2012-Nov-03 Update: 
 * * Updated OpenID.php to lastest version
 * * Fixed many issues preventing authentication
 * * Added cleaning up of URL when finished
 * * Added a global var when OpenID fails (e.g. with improper URL)     
 */


//Add recipe info to pmwiki
$RecipeInfo['FAuth']['Version'] = '20121103';
//Extension sanity checks:
if (!defined('PmWiki')) exit();
if ($EnableAuthUser == 1){
  echo 'Error in Cookbook fauth.php: Authuser extensions like fauth.php must be included before authuser.php';
  exit;
}
//Require mit-licenced lib for open id
require_once 'openid.php';

//Define markup for federated auth buttons
//Usage of the markup should be pretty straightforward
Markup("google_loginbox", "directives", '/\\(:google_loginbox:\\)/ei', "GoogleLoginBox()");
Markup("openid_loginbox", "directives", '/\\(:openid_loginbox:\\)/ei', "OpenIDLoginBox()");

//Add the function to validate authentication (enabled from SiteAdmin.AuthUser)
$AuthUserFunctions['google'] = 'AuthUserOpenID';
$AuthUserFunctions['openid'] = 'AuthUserOpenID';

//Do we have open-id response as a request?
$openid = new LightOpenID(stripExtras($ScriptUrl)."/"); 
if ($openid->mode) {  
    //We have signal (and open id)
    //If all is well -> push the id to @_POST for authuser
    if($openid->validate()){
        $attr=$openid->getAttributes();

        //@TODO:Should have option in local/nofig.php etc. to set required params
        if(!empty($attr['namePerson/first']) && !empty($attr['namePerson/last'])){
          @$_POST['authid'] = $attr['namePerson/first']." ".$attr['namePerson/last'];
        }
        else{
          @$_POST['authid']=getIdentityAsAuthID();
        }
      //End reduntant validation
      //}
      @$_POST['passedOpenID'] = true;
      
      //clean the url
      header('Location: ' . CleanURL());
    }
    else
      @$_POST['passedOpenID'] = false;
    
} //No -> maybe its an login relay request then?
else{
  //A login attempt with google login -> try to login trough google
  if(isset($_REQUEST['google_login'])) {
    #$openid = new LightOpenID('softwareaccessibility.com');
    $openid->required = array('namePerson/first','namePerson/last', 'contact/email','contact/country/home');

    //Google auth uses uniform address (and medles with cookies)
    $openid->identity = 'https://www.google.com/accounts/o8/id';
    header('Location: ' . $openid->authUrl());
  }
  //A login attempt with standard OpenID provider -> try login with given id
  else if(isset($_REQUEST['openid_login'])){
    #$openid = new LightOpenID(stripExtras($ScriptUrl));
    $openid->required = array('namePerson/first','namePerson/last', 'contact/email','contact/country/home');

    //Normally we can just use the id user gave us!
    $openid->identity =  $openid->identity = $_REQUEST['openid_identifier'];
    try {
      header('Location: ' . $openid->authUrl());
    } catch(ErrorException $e) {
      $GLOBALS['BadOpenID'] = 1; return;
    }
  }
}



/**
 *Loginbox for Google
 */
function GoogleLoginBox(){
  if ($_REQUEST['action']>'') $action='&action='.$_REQUEST['action'];
	$output = '<form action="?google_login'.$action.'" method="post"><button>Login with Google</button></form>';
	return $output;
}

/**
 *Loginbox for standard provider
 */
function OpenIDLoginBox(){
  if ($_REQUEST['action']>'') $action='&action='.$_REQUEST['action'];
	$output = '<form action="?openid_login'.$action.'" method="post"><label for="openid_identifier">OpenID Identifier<input id="openid_identifier" name="openid_identifier" type="text" size="30"/></label><button>Login with OpenID</button></form>';
	return $output;
}

/**
 * This function checks login from request parameters
 */
function AuthUserOpenID($pagename, $id, $pw, $pwlist) {
  
  try{
    #$openid = new LightOpenID(stripExtras($ScriptUrl."/"));

    //Check if we can validate the session from OpenID provider
    if(@$_POST['passedOpenID'] === true){        
      return true;
    }

    //nope, return false    
    return false;
  } catch(ErrorException $e) {
    return false;
  }
}

/**
 *Convert and identity to an authid
 */
function getIdentityAsAuthID(){

  $original=$_REQUEST['openid.identity'];
  if (empty($original)) $original=$_REQUEST['openid_identity'];

  /*$fixed=str_replace("~", "-", $original);
  $fixed=str_replace("https://", "",$fixed);
  $fixed=str_replace("http://", "",$fixed);
  $fixed=str_replace("/", "-",$fixed);   */

  return stripExtras($original); #$fixed;
}

function stripExtras($aData) {
  $fixed=str_replace("~", "-", $aData);
  $fixed=str_replace("https://", "",$fixed);
  $fixed=str_replace("http://", "",$fixed);
  $fixed=str_replace("/", "-",$fixed);

  return $fixed;
}

function CleanURL() {
  #removes everthing about open id, ther should only be two params left
  $url = substr(selfURL(), 0, stripos(selfURL(), "&openid"));
  
  #remove openid login
  $url = str_replace("openid_login&", "", $url);
  
  #remove the google login and return the cleaned URL
  return str_replace("google_login&","", $url);  
}

#from http://stackoverflow.com/a/8891890
function selfURL(){ 
    $s = empty($_SERVER["HTTPS"]) ? '' : ($_SERVER["HTTPS"] == "on") ? "s" : "";
    $protocol = substr(strtolower($_SERVER["SERVER_PROTOCOL"]), 0, strpos(strtolower($_SERVER["SERVER_PROTOCOL"]), "/")) . $s;
    $port = ($_SERVER["SERVER_PORT"] == "80") ? "" : (":".$_SERVER["SERVER_PORT"]);
    return $protocol . "://" . $_SERVER['SERVER_NAME'] . $port . $_SERVER['REQUEST_URI'];
}
